package com.poscodx.movie.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.poscodx.movie.controller.CommentController;
import com.poscodx.movie.controller.MovieController;
import com.poscodx.movie.model.CommentDTO;
import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.util.ConnectionMaker;
import com.poscodx.movie.util.MySqlConnectionMaker;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "GradeAllServlet", urlPatterns = "/gradeall")

public class GradeAllServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        ConnectionMaker connectionMaker = new MySqlConnectionMaker();
        CommentController commentController = new CommentController(connectionMaker);

        int id = Integer.parseInt(req.getParameter("id"));

        List<CommentDTO> list = commentController.selectAll(id);
        Gson gson = new Gson();
        JsonArray array = new JsonArray();
        for (CommentDTO r: list){
            array.add(gson.toJsonTree(r));

        }

        JsonObject object = new JsonObject();
        object.addProperty("status", "success");
        object.addProperty("replys", gson.toJson(array));

        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().println(gson.toJson(object));

    }

}

package com.poscodx.movie.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySqlConnectionMaker implements ConnectionMaker {

    private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String URL = "jdbc:mysql://localhost:3306/movie";
    private final String USERNAME = "root";
    private final String PASSWORD = "0000";

    @Override
    public Connection makeConnection() {
        Connection connection =  null;

        try{
            Class.forName(DRIVER);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

        }catch (Exception e){
            e.printStackTrace();
        }

        return connection;
    }
}

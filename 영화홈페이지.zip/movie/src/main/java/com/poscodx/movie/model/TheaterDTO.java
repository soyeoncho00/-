package com.poscodx.movie.model;

import lombok.Data;

import java.util.Date;

@Data
public class TheaterDTO {
    private int thnum;
    private String theater_name;
    private String loc;
    private String tel;
    private String title;
    private String url;

    private String grade;
    private String genre;
    private Date start_date;

    private int mnum;
}

package com.poscodx.movie.controller;

import com.poscodx.movie.model.ScreenDTO;
import com.poscodx.movie.model.TheaterDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ScreenController {

    private Connection connection;
    public ScreenController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public List<ScreenDTO> select(int mnum){
        List<ScreenDTO> list = new ArrayList<>();

        String query = "select * from movie " +
                "    inner join screen" +
                "    on movie.mnum = screen.mnum" +
                "    inner join theater " +
                "    on theater.thnum = screen.thnum WHERE screen.mnum = ? order by screen.thnum;";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                ScreenDTO screenDTO = new ScreenDTO();

                screenDTO.setIdx(resultSet.getInt("id"));
                screenDTO.setMnum(resultSet.getInt("mnum"));
                screenDTO.setThnum(resultSet.getInt("thnum"));
                screenDTO.setThname(resultSet.getString("name"));
                screenDTO.setTitle(resultSet.getString("title"));
                screenDTO.setStart_date(resultSet.getDate("start_date"));
                screenDTO.setEnd_date(resultSet.getDate("end_date"));

                list.add(screenDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public void insert(int mnum, int thnum, String start_date, String end_date){
        String query = "INSERT INTO screen(mnum, thnum, start_date, end_date) VALUES (?,?,?,?)";

        try {
            PreparedStatement preparedStatement = this.connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            preparedStatement.setInt(2, thnum);


            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate1 = null;
            java.util.Date parsedDate2 = null;
            try {
                parsedDate1 = newDtFormat.parse(start_date);
                parsedDate2 = newDtFormat.parse(end_date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate1.getTime());
            java.sql.Date sqlEndDate = new java.sql.Date(parsedDate2.getTime());

            preparedStatement.setDate(3, sqlStartDate);
            preparedStatement.setDate(4, sqlEndDate);

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void remove(int id){
        String query = "DELETE FROM screen WHERE id = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void update(int idx,int thnum, String start_date, String end_date){

        String query = "UPDATE screen SET thnum = ?, start_date = ?, end_date = ?, modify_date = NOW() WHERE id = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, thnum);

            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate1 = null;
            java.util.Date parsedDate2 = null;

            try {
                parsedDate1 = newDtFormat.parse(start_date);
                parsedDate2 = newDtFormat.parse(end_date);

            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate1.getTime());
            java.sql.Date sqlEndDate = new java.sql.Date(parsedDate2.getTime());

            preparedStatement.setDate(2, sqlStartDate);
            preparedStatement.setDate(3, sqlEndDate);

            preparedStatement.setInt(4, idx);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}

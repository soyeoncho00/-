package com.poscodx.movie.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.poscodx.movie.controller.MovieController;
import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.util.ConnectionMaker;
import com.poscodx.movie.util.MySqlConnectionMaker;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet(name = "MovieUpdateServlet", urlPatterns = "/updatemovie")

public class MovieUpdateServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Gson gson = new Gson();
        String param = req.getParameter("param");
        JsonObject object = JsonParser.parseString(param).getAsJsonObject();
        ConnectionMaker connectionMaker = new MySqlConnectionMaker();
        MovieController movieController = new MovieController(connectionMaker);

        var id = object.get("mnum").getAsInt();
        var img_src = object.get("img_src").getAsString();
        var title = object.get("title").getAsString();
        var start_date = object.get("start_date").getAsString();

        var runningtime = object.get("runningtime").getAsInt();
        var grade = object.get("grade").getAsString();
        var summary = object.get("summary").getAsString();
        var director = object.get("director").getAsString();
        var genre = object.get("genre").getAsString();
        var actors = object.get("actors").getAsString();

        movieController.update(id, img_src, title, runningtime, grade, summary, director, genre, actors, start_date);

        List<MovieDTO> list = movieController.selectAll();
        JsonArray array = new JsonArray();

        for (MovieDTO r: list){
            array.add(gson.toJsonTree(r));
        }

        object = new JsonObject();
        object.addProperty("status", "success");
        object.addProperty("replys", gson.toJson(array));

        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().println(gson.toJson(object));
    }

}

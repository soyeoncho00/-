package com.poscodx.movie.model;

import lombok.Data;

import java.util.Date;

@Data
public class MovieDTO {

    private int mnum;
    private String title;
    private String summary;
    private String grade;
    private String url;
    private int runningtime;
    private Date startdate;
    private Date endate;
    private String genre;
    private String director;
    private String actors;
    private double avg;

}

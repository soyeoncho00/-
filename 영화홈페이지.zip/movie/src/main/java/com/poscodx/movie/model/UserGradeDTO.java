package com.poscodx.movie.model;

import lombok.Data;

@Data
public class UserGradeDTO {
    private int id;
    private String nickname;
    private String oldgrade;
    private String newgrade;
}

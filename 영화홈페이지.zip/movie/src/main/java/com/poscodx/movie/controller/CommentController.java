package com.poscodx.movie.controller;

import com.poscodx.movie.model.CommentDTO;
import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.model.UserDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CommentController {

    private Connection connection;
    public CommentController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public CommentDTO auth(int id, int mnum){

        String query = "SELECT * FROM grade WHERE userid = ? and mnum = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.setInt(2, mnum);


            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                CommentDTO commentDTO = new CommentDTO();

                commentDTO.setUserid(resultSet.getInt("userid"));
                commentDTO.setMnum(resultSet.getInt("mnum"));
                commentDTO.setGrade(resultSet.getInt("grade"));
                commentDTO.setComment(resultSet.getString("comment"));
                commentDTO.setEntry_date(resultSet.getDate("entry_date"));

                return commentDTO;
            }

        }catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }




    public List<CommentDTO> selectAll(int mnum){
        List<CommentDTO> list = new ArrayList<>();

        String query = "SELECT * FROM movie " +
                "LEFT JOIN (select id, userid, mnum, grade as rating, comment, entry_date from grade) grade ON grade.mnum = movie.mnum " +
                "LEFT JOIN user ON user.mnum = grade.userid  WHERE grade.mnum = ? order by grade.entry_date";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                CommentDTO commentDTO = new CommentDTO();

                commentDTO.setUserid(resultSet.getInt("id"));
                commentDTO.setNickname(resultSet.getString("nickname"));
                commentDTO.setMnum(resultSet.getInt("mnum"));
                commentDTO.setComment(resultSet.getString("comment"));
                commentDTO.setEntry_date(resultSet.getDate("entry_date"));
                commentDTO.setGrade(resultSet.getInt("rating"));
//                commentDTO.setAvg(resultSet.getDouble("avg"));

                list.add(commentDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public List<CommentDTO> selectPro(int mnum){
        List<CommentDTO> list = new ArrayList<>();

        String query = "SELECT * FROM movie " +
                "LEFT JOIN (SELECT id, userid, mnum, grade as rating, comment," +
                "       AVG(grade) OVER(PARTITION BY mnum) AS avg, entry_date " +
                "FROM grade) as grade ON grade.mnum = movie.mnum " +
                "LEFT JOIN user ON user.mnum = grade.userid " +
                "where user.position='전문평론가' and grade.mnum = ?" +
                " order by grade.entry_date";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                CommentDTO commentDTO = new CommentDTO();

                commentDTO.setUserid(resultSet.getInt("id"));
                commentDTO.setNickname(resultSet.getString("nickname"));
                commentDTO.setMnum(resultSet.getInt("mnum"));
                commentDTO.setComment(resultSet.getString("comment"));
                commentDTO.setEntry_date(resultSet.getDate("entry_date"));
//                commentDTO.setAvg(resultSet.getDouble("avg"));
                commentDTO.setGrade(resultSet.getInt("rating"));

                list.add(commentDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public List<CommentDTO> selectUser(int mnum){
        List<CommentDTO> list = new ArrayList<>();

        String query = "SELECT * FROM movie " +
                "LEFT JOIN (SELECT id, userid, mnum, grade as rating, comment," +
                "       AVG(grade) OVER(PARTITION BY mnum) AS avg, entry_date " +
                "FROM grade) as grade ON grade.mnum = movie.mnum " +
                "LEFT JOIN user ON user.mnum = grade.userid " +
                "where user.position='일반회원' and grade.mnum = ?" +
                " order by grade.entry_date";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                CommentDTO commentDTO = new CommentDTO();

                commentDTO.setNickname(resultSet.getString("nickname"));
                commentDTO.setMnum(resultSet.getInt("mnum"));
                commentDTO.setEntry_date(resultSet.getDate("entry_date"));
                commentDTO.setGrade(resultSet.getInt("rating"));

                list.add(commentDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public void insert(int userid, int mnum, int grade, String comment) {

        String query = "INSERT INTO grade(userid, mnum, grade, comment) VALUES (?,?,?,?)";

        try {
            PreparedStatement preparedStatement = this.connection.prepareStatement(query);
            preparedStatement.setInt(1, userid);
            preparedStatement.setInt(2, mnum);
            preparedStatement.setInt(3, grade);
            preparedStatement.setString(4, comment);

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void insert2(int userid, int mnum, int grade) {

        String query = "INSERT INTO grade(userid, mnum, grade) VALUES (?,?,?)";

        try {
            PreparedStatement preparedStatement = this.connection.prepareStatement(query);
            preparedStatement.setInt(1, userid);
            preparedStatement.setInt(2, mnum);
            preparedStatement.setInt(3, grade);

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}


package com.poscodx.movie.model;

import lombok.Data;

import java.util.Date;

@Data
public class CommentDTO {
    private int userid;
    private String nickname;
    private int mnum;
    private int grade;
    private String comment;
    private Date entry_date;
}

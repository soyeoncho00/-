package com.poscodx.movie.model;

import lombok.Data;

@Data
public class UserDTO {

    private int mnum;
    private String id;
    private String password;
    private String nickname;
    private String position;
}

package com.poscodx.movie.util;

import java.sql.Connection;


public interface ConnectionMaker {
    public Connection makeConnection();
}

package com.poscodx.movie.controller;

import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

public class MovieController {

    private Connection connection;
    public MovieController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public List<MovieDTO> selectName(){
        List<MovieDTO> list = new ArrayList<>();

        String query = "SELECT * FROM MOVIE";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));

                list.add(movieDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;

    }


    public List<MovieDTO> selectAll(){
        List<MovieDTO> list = new ArrayList<>();

        String query = "select * from movie left join (SELECT mnum, min(thnum) as thnum, min(start_date) as start_date, min(end_date) as end_date FROM screen group by mnum) s on movie.mnum = s.mnum" +
                " LEFT JOIN (SELECT mnum, AVG(grade) AS avg" +
                " FROM grade GROUP BY mnum) AS g ON movie.mnum = g.mnum order by movie.mnum";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));
                movieDTO.setSummary(resultSet.getString("summary"));
                movieDTO.setGrade(resultSet.getString("grade"));
                movieDTO.setUrl(resultSet.getString("url"));
                movieDTO.setRunningtime(resultSet.getInt("runningtime"));
                movieDTO.setStartdate(resultSet.getDate("start_date"));
                movieDTO.setEndate(resultSet.getDate("end_date"));
                movieDTO.setGenre(resultSet.getString("genre"));
                movieDTO.setDirector(resultSet.getString("director"));
                movieDTO.setActors(resultSet.getString("actors"));
                movieDTO.setAvg(resultSet.getDouble("avg"));

                list.add(movieDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public List<MovieDTO> filter(String date){
        List<MovieDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER " +
                "    LEFT JOIN SCREEN ON THEATER.THNUM = SCREEN.THNUM " +
                "    LEFT JOIN MOVIE ON SCREEN.MNUM = MOVIE.MNUM WHERE " +
                "    AND start_date <= ? and end_date >= NOW() ORDER BY theater.thnum";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = null;
            try {
                parsedDate = newDtFormat.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate.getTime());
                preparedStatement.setDate(1, sqlStartDate);

            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));
                movieDTO.setSummary(resultSet.getString("summary"));
                movieDTO.setGrade(resultSet.getString("grade"));
                movieDTO.setUrl(resultSet.getString("url"));
                movieDTO.setRunningtime(resultSet.getInt("runningtime"));
                movieDTO.setStartdate(resultSet.getDate("start_date"));
                movieDTO.setEndate(resultSet.getDate("end_date"));
                movieDTO.setGenre(resultSet.getString("genre"));
                movieDTO.setDirector(resultSet.getString("director"));
                movieDTO.setActors(resultSet.getString("actors"));
                movieDTO.setAvg(resultSet.getDouble("avg"));

                list.add(movieDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public List<MovieDTO> selectOnAll(){ /*현재 상영작 모두 출력*/
        List<MovieDTO> list = new ArrayList<>();

        String query = "select * from movie left join (SELECT mnum, min(thnum) as thnum, min(start_date) as start_date, min(end_date) as end_date FROM screen group by mnum HAVING start_date <= NOW() AND end_date >= NOW()) s on movie.mnum = s.mnum" +
                " LEFT JOIN (SELECT mnum, AVG(grade) AS avg" +
                " FROM grade GROUP BY mnum) AS g ON movie.mnum = g.mnum where movie.startdate <= NOW() order by movie.mnum";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));
                movieDTO.setSummary(resultSet.getString("summary"));
                movieDTO.setGrade(resultSet.getString("grade"));
                movieDTO.setUrl(resultSet.getString("url"));
                movieDTO.setRunningtime(resultSet.getInt("runningtime"));
                movieDTO.setStartdate(resultSet.getDate("start_date"));
                movieDTO.setEndate(resultSet.getDate("end_date"));
                movieDTO.setGenre(resultSet.getString("genre"));
                movieDTO.setDirector(resultSet.getString("director"));
                movieDTO.setActors(resultSet.getString("actors"));
                movieDTO.setAvg(resultSet.getDouble("avg"));
                list.add(movieDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public List<MovieDTO> selectFAll(){ /*상영예정작 모두 출력*/
        List<MovieDTO> list = new ArrayList<>();
        String query = "select * from movie left join (SELECT mnum, min(thnum) as thnum, min(start_date) as start_date, min(end_date) as end_date FROM screen group by mnum HAVING start_date > NOW()) s on movie.mnum = s.mnum" +
                " LEFT JOIN (SELECT mnum, AVG(grade) AS avg" +
                " FROM grade GROUP BY mnum) AS g ON movie.mnum = g.mnum where movie.startdate >= NOW() order by movie.mnum";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));
                movieDTO.setSummary(resultSet.getString("summary"));
                movieDTO.setGrade(resultSet.getString("grade"));
                movieDTO.setUrl(resultSet.getString("url"));
                movieDTO.setRunningtime(resultSet.getInt("runningtime"));
                movieDTO.setStartdate(resultSet.getDate("start_date"));
                movieDTO.setEndate(resultSet.getDate("end_date"));
                movieDTO.setGenre(resultSet.getString("genre"));
                movieDTO.setDirector(resultSet.getString("director"));
                movieDTO.setActors(resultSet.getString("actors"));
                movieDTO.setAvg(resultSet.getDouble("avg"));

                list.add(movieDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public MovieDTO selectOnOne(int id){

        String query = "select * from movie left join (SELECT mnum, min(thnum) as thnum, min(start_date) as start_date, min(end_date) as end_date FROM screen group by mnum) s on movie.mnum = s.mnum"+
        " LEFT JOIN (SELECT mnum, AVG(grade) AS avg"+
        " FROM grade GROUP BY mnum) AS g ON movie.mnum = g.mnum where movie.mnum = ?";


        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()){
                MovieDTO movieDTO = new MovieDTO();
                movieDTO.setMnum(resultSet.getInt("mnum"));
                movieDTO.setTitle(resultSet.getString("title"));
                movieDTO.setSummary(resultSet.getString("summary"));
                movieDTO.setGrade(resultSet.getString("grade"));
                movieDTO.setUrl(resultSet.getString("url"));
                movieDTO.setRunningtime(resultSet.getInt("runningtime"));
                movieDTO.setStartdate(resultSet.getDate("startdate"));
                movieDTO.setEndate(resultSet.getDate("end_date"));
                movieDTO.setGenre(resultSet.getString("genre"));
                movieDTO.setDirector(resultSet.getString("director"));
                movieDTO.setActors(resultSet.getString("actors"));
                movieDTO.setAvg(resultSet.getDouble("avg"));

                return movieDTO;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public void remove(int id){
        String query = "DELETE FROM movie WHERE mnum = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void update(int id, String img_src, String title, int runningtime, String grade, String summary, String director, String genre, String actors, String start_date){

        String query = "UPDATE movie SET url = ?, title = ?, runningtime = ?, grade = ?," +
                " summary = ?, director = ?, genre = ?, actors = ?, startdate = ? WHERE mnum = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, img_src);
            preparedStatement.setString(2, title);
            preparedStatement.setInt(3, runningtime);
            preparedStatement.setString(4, grade);
            preparedStatement.setString(5, summary);
            preparedStatement.setString(6, director);
            preparedStatement.setString(7, genre);
            preparedStatement.setString(8, actors);
            preparedStatement.setInt(10, id);

            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = null;
            try {
                parsedDate = newDtFormat.parse(start_date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate.getTime());
            preparedStatement.setDate(9, sqlStartDate);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void insert(String img_src, String title, int runningtime, String grade, String summary, String director, String genre, String actors, String start_date){
        String query = "INSERT INTO movie(url, title, runningtime, grade, summary, director, genre, actors, startdate) VALUES (?,?,?,?,?,?,?,?,?)";

        try {
            PreparedStatement preparedStatement = this.connection.prepareStatement(query);
            preparedStatement.setString(1, img_src);
            preparedStatement.setString(2, title);
            preparedStatement.setInt(3, runningtime);
            preparedStatement.setString(4, grade);
            preparedStatement.setString(5, summary);
            preparedStatement.setString(6, director);
            preparedStatement.setString(7, genre);
            preparedStatement.setString(8, actors);

            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = null;
            try {
                parsedDate = newDtFormat.parse(start_date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate.getTime());
            preparedStatement.setDate(9, sqlStartDate);

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}

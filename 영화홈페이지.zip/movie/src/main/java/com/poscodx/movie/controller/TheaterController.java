package com.poscodx.movie.controller;

import com.poscodx.movie.model.CommentDTO;
import com.poscodx.movie.model.TheaterDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TheaterController {

    private Connection connection;
    public TheaterController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public List<TheaterDTO> selectAll(){
        List<TheaterDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER " +
                "    LEFT JOIN SCREEN ON THEATER.THNUM = SCREEN.THNUM " +
                "    LEFT JOIN MOVIE ON SCREEN.MNUM = MOVIE.MNUM " +
                "    ORDER BY theater.thnum;";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));
                theaterDTO.setTitle(resultSet.getString("title"));
                theaterDTO.setUrl(resultSet.getString("url"));
                theaterDTO.setGrade(resultSet.getString("grade"));
                theaterDTO.setGenre(resultSet.getString("genre"));
                theaterDTO.setStart_date(resultSet.getDate("start_date"));
                theaterDTO.setMnum(resultSet.getInt("mnum"));

                list.add(theaterDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public List<TheaterDTO> selectAllCinema(){
        List<TheaterDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setThnum(resultSet.getInt("thnum"));
                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));

                list.add(theaterDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public List<TheaterDTO> selectCinema(int thnum){
        List<TheaterDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER " +
                "    LEFT JOIN SCREEN ON THEATER.THNUM = SCREEN.THNUM " +
                "    LEFT JOIN MOVIE ON SCREEN.MNUM = MOVIE.MNUM WHERE theater.thnum = ?" +
                "    ORDER BY theater.thnum;";
//AND start_date <= NOW() and end_date >= NOW()
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, thnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setThnum(resultSet.getInt("thnum"));
                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));
                theaterDTO.setTitle(resultSet.getString("title"));
                theaterDTO.setUrl(resultSet.getString("url"));
                theaterDTO.setMnum(resultSet.getInt("mnum"));

                theaterDTO.setGrade(resultSet.getString("grade"));
                theaterDTO.setGenre(resultSet.getString("genre"));
                theaterDTO.setStart_date(resultSet.getDate("start_date"));

                list.add(theaterDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }



    public TheaterDTO selectOne(int thnum){

        String query = "SELECT * FROM THEATER WHERE thnum = ? ";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, thnum);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setThnum(resultSet.getInt("thnum"));
                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));

                return theaterDTO;
            }
        }catch (Exception e){
            return null;
//            e.printStackTrace();
        }
        return null;
    }


    public List<TheaterDTO> select(){
        List<TheaterDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setThnum(resultSet.getInt("thnum"));
                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));

                list.add(theaterDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }



    public List<TheaterDTO> filter(int thnum, String date){
        List<TheaterDTO> list = new ArrayList<>();

        String query = "SELECT * FROM THEATER " +
                "    LEFT JOIN SCREEN ON THEATER.THNUM = SCREEN.THNUM " +
                "    LEFT JOIN MOVIE ON SCREEN.MNUM = MOVIE.MNUM WHERE theater.thnum = ?" +
                "    AND start_date <= ? and end_date >= ? ORDER BY theater.thnum;";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, thnum);

            SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = null;
            try {
                parsedDate = newDtFormat.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Date sqlStartDate = new java.sql.Date(parsedDate.getTime());
            preparedStatement.setDate(2, sqlStartDate);
            preparedStatement.setDate(3, sqlStartDate);

            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                TheaterDTO theaterDTO = new TheaterDTO();

                theaterDTO.setThnum(resultSet.getInt("thnum"));
                theaterDTO.setTheater_name(resultSet.getString("name"));
                theaterDTO.setLoc(resultSet.getString("loc"));
                theaterDTO.setTel(resultSet.getString("tel"));
                theaterDTO.setTitle(resultSet.getString("title"));
                theaterDTO.setUrl(resultSet.getString("url"));
                theaterDTO.setMnum(resultSet.getInt("mnum"));

                theaterDTO.setGrade(resultSet.getString("grade"));
                theaterDTO.setGenre(resultSet.getString("genre"));
                theaterDTO.setStart_date(resultSet.getDate("start_date"));

                list.add(theaterDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public void register(String thname, String thtel, String thloc){
        String query = "INSERT INTO theater (name, loc, tel) VALUES (?,?,?)";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, thname);
            preparedStatement.setString(2, thtel);
            preparedStatement.setString(3, thloc);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void remove(int id){
        String query = "DELETE FROM theater WHERE thnum = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public void update(int id, String thname, String thloc, String thtel){

        String query = "UPDATE theater SET name = ?, loc = ?, tel = ?, modify_date = NOW() WHERE thnum = ?" ;

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, thname);
            preparedStatement.setString(2, thloc);
            preparedStatement.setString(3, thtel);
            preparedStatement.setInt(4, id);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }



}

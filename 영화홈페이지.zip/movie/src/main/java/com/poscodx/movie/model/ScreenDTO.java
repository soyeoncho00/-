package com.poscodx.movie.model;

import lombok.Data;

import java.util.Date;

@Data
public class ScreenDTO {

    private int idx;
    private int mnum;
    private int thnum;
    private Date start_date;
    private Date end_date;
    private String title;
    private String thname;

}

package com.poscodx.movie.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.poscodx.movie.controller.MovieController;
import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.util.ConnectionMaker;
import com.poscodx.movie.util.MySqlConnectionMaker;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet(name = "MovieServlet", urlPatterns = "/movie")
public class MovieServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        ConnectionMaker connectionMaker = new MySqlConnectionMaker();
        MovieController movieController = new MovieController(connectionMaker);

        List<MovieDTO> list = movieController.selectOnAll();

        Gson gson = new Gson();
        JsonArray array = new JsonArray();
        for (MovieDTO r: list){
            array.add(gson.toJsonTree(r));
        }
        JsonObject object = new JsonObject();
        object.addProperty("status", "success");
        object.addProperty("replys", gson.toJson(array));

        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().println(gson.toJson(object));

    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{

        String param = req.getParameter("param");
        JsonObject object = JsonParser.parseString(param).getAsJsonObject();

        ConnectionMaker connectionMaker = new MySqlConnectionMaker();
        MovieController movieController = new MovieController(connectionMaker);
        var start_time = object.get("start_time").getAsString();

        List<MovieDTO> list = movieController.filter(start_time);

        Gson gson = new Gson();
        JsonArray array = new JsonArray();
        for (MovieDTO r: list){
            array.add(gson.toJsonTree(r));
        }
        object = new JsonObject();
        object.addProperty("status", "success");
        object.addProperty("replys", gson.toJson(array));

        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().println(gson.toJson(object));

    }
}

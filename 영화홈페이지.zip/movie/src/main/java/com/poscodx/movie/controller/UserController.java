package com.poscodx.movie.controller;
import com.poscodx.movie.model.UserDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class UserController {

    private Connection connection;
    public UserController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public UserDTO auth(String id, String password){

        String query = "SELECT * FROM user WHERE id = ? AND password = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                UserDTO userDTO = new UserDTO();
                userDTO.setMnum(resultSet.getInt("mnum"));
                userDTO.setId(id);
                userDTO.setPassword(password);
                userDTO.setNickname(resultSet.getString("nickname"));
                userDTO.setPosition(resultSet.getString("position"));
                return userDTO;
            }

        }catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void register(String id, String password, String nickname){
        String query = "INSERT INTO user(id, password, nickname) VALUES (?,?,?)";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, nickname);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public boolean validateId(String id){
        String query = "SELECT * FROM user WHERE id = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                return true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public void changeGrade(int mnum, String oldGrade, String newGrade){
        String query = "INSERT INTO changeuser(userid, oldgrade, newgrade) VALUES (?,?,?)";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, mnum);
            preparedStatement.setString(2, oldGrade);
            preparedStatement.setString(3, newGrade);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void update(int id, String newgrade){

        String query = "UPDATE user SET position = ? WHERE mnum = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newgrade);
            preparedStatement.setInt(2, id);

            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}

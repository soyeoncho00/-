package com.poscodx.movie.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.poscodx.movie.controller.CommentController;
import com.poscodx.movie.controller.MovieController;
import com.poscodx.movie.controller.UserGradeController;
import com.poscodx.movie.model.CommentDTO;
import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.util.ConnectionMaker;
import com.poscodx.movie.util.MySqlConnectionMaker;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "GradeRatingInsertServlet", urlPatterns = "/insertrating")
public class GradeRatingInsertServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Gson gson = new Gson();
        String param = req.getParameter("param");
        JsonObject object = JsonParser.parseString(param).getAsJsonObject();
        ConnectionMaker connectionMaker = new MySqlConnectionMaker();
        CommentController commentController = new CommentController(connectionMaker);

        var userid = object.get("userid").getAsInt();
        var mnum = object.get("mnum").getAsInt();
        var position = object.get("grade").getAsInt();
        var comment = object.get("comment").getAsString();

        CommentDTO commentDTO = commentController.auth(userid, mnum);

        if (commentDTO == null) {
            if (comment.equals("default")) {
                commentController.insert2(userid, mnum, position);
            } else {
                commentController.insert(userid, mnum, position, comment);
            }
            object = new JsonObject();
            object.addProperty("status", "success");

            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().println(gson.toJson(object));
        } else {
            object = new JsonObject();
            object.addProperty("status", "error");
            object.addProperty("message", "이미 등록된 평점이 있습니다.");

            resp.setContentType("application/json;charset=UTF-8");
            resp.getWriter().println(gson.toJson(object));
        }
    }
}

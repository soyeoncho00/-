package com.poscodx.movie.controller;

import com.poscodx.movie.model.MovieDTO;
import com.poscodx.movie.model.UserGradeDTO;
import com.poscodx.movie.util.ConnectionMaker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class UserGradeController {

    private Connection connection;
    public UserGradeController(ConnectionMaker connectionMaker){
        connection = connectionMaker.makeConnection();
    }

    public List<UserGradeDTO> selectAll(){
        List<UserGradeDTO> list = new ArrayList<>();

        String query = "select * from user inner join changeuser on user.mnum = changeuser.userid order by changeuser.userid";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                UserGradeDTO userGradeDTO = new UserGradeDTO();

                userGradeDTO.setId(resultSet.getInt("mnum"));
                userGradeDTO.setNickname(resultSet.getString("nickname"));
                userGradeDTO.setOldgrade(resultSet.getString("oldgrade"));
                userGradeDTO.setNewgrade(resultSet.getString("newgrade"));

                list.add(userGradeDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public UserGradeDTO selectOnOne(int id){

        String query = "select * from user inner join changeuser on user.mnum = changeuser.userid " +
                "where changeuser.userid = ? order by changeuser.userid";


        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()){
                UserGradeDTO userGradeDTO = new UserGradeDTO();

                userGradeDTO.setId(resultSet.getInt("idx"));
                userGradeDTO.setNickname(resultSet.getString("nickname"));
                userGradeDTO.setOldgrade(resultSet.getString("oldgrade"));
                userGradeDTO.setNewgrade(resultSet.getString("newgrade"));

                return userGradeDTO;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public void remove(int id){
        String query = "DELETE FROM changeuser WHERE userid = ?";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
